#!/bin/bash

echo "Nginx is running..."

exec nginx -g "daemon off;"
